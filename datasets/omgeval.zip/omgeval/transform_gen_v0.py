import random

def transform(data, num_sample: int, r: random.Random, dataset_name: str):
    
    # Okapi
    text = f"[INST] {data['question']} [/INST]"

    # Bloomz-7b1-mt
    #text = f"{data['question']}"
    #text = f"请回答以下问题：{data['question']}"
    #text = f"Please answer the following questions:{data['question']}"
    #text = f"الرجاء الإجابة على الأسئلة التالية:{data['question']}"
    #text = f"Por favor, conteste a las siguientes preguntas:{data['question']}"
    #text = f"Merci de répondre aux questions suivantes:{data['question']}"
    #text = f"Пожалуйста, ответьте на следующие вопросы:{data['question']}"
    
    
    


    # PolyLM-Multialpaca-13B
    #text = f"{data['question'].strip()}\n\n"
    # PolyLM-Chat-13B
    #text = f"<|user|>\n{data['question'].strip()}<|assistant|>\n"
    #original
    #text = f"Question: {data['question']}\nAnswer: "

    #DEFAULT_PROMPT = "you are a helpful AI assistant. please answer questions."
    #DEFAULT_PROMPT = "vous êtes un assistant IA utile. Veuillez répondre aux questions."
    #DEFAULT_PROMPT = "你是一个有帮助的AI助手，请回答问题。"
    #DEFAULT_PROMPT = "вы полезный помощник ИИ. пожалуйста, ответьте на вопросы."
    #DEFAULT_PROMPT = "Eres un útil asistente de IA. por favor responda las preguntas."
    #DEFAULT_PROMPT = "أنت مساعد AI مفيد. يرجى الإجابة على الأسئلة."

    #text= DEFAULT_PROMPT + data['question']
    return {
        "input": text, 
        #"input": text.strip(), 
        "output": "", 
        "processed_output": ""
        }
