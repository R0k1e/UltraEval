import os
import subprocess
from transform_humaneval import transform_humaneval
from omgeval import omg_eval
import time
import signal

# languages = ['en', 'zh', 'es', 'ru', 'fr']
languages = ['ar']
# lang_list = ['es', 'ru', 'fr']
# model_list = ['okapi', 'bloom', 'polyalpaca', 'polychat', 'guanaco', 'phoenix', "guanaco-13b"]
model_list = ['chimera-13b']
# test_list = ['humaneval', 'mgsm', 'omgeval']
# test_list = ['humaneval']
test_list = ['omgeval']
port = 6323

template_dict = {
    'llama-7b': 'llama',
    'llama-13b': 'llama',
    'llama-70b': 'llama',
    'guanaco-13b': 'guanaco-13b',
    'guanaco-7b': 'guanaco',
    'phoenix-7b': 'phoenix',
    'chimera-13b': 'phoenix',
    'omg-lm': 'okapi'
}

model_path = {
    'bloom': "/data/public/wangshuo/bloomz-7b1-mt",
    'okapi': "/data/public/wangshuo/PolyLM-multialpaca-13b",
    'polychat': "/data/public/wangshuo/polylm-chat-13b",
    'llama-7b': "/data/public/opensource_models/meta-llama/Llama-2-7b-chat-hf",
    'llama-13b': "/data/public/opensource_models/meta-llama/Llama-2-13b-chat-hf",
    'llama-70b': "/data/public/opensource_models/meta-llama/Llama-2-70b-chat-hf",
    'omg-lm': "/data/public/wangshuo/exp/ft-5lang-omg-13b/ckpts/checkpoints/epoch_2_hf",
    'phoenix-7b': " /home/wanghaoyu/analyse_data/phoenix-inst-chat-7b",
    'chimera-13b': " /home/wanghaoyu/analyse_data/chimera-inst-chat-13b",
    'guanaco-13b': " /home/wanghaoyu/analyse_data/guanaco-13b-hf",
    'guanaco-7b': " /home/wanghaoyu/analyse_data/Guanaco",
}

def auto_test(model):
    template_type = template_dict[model]
    for test_set in test_list:
        for lang in languages:
            os.system(f"bash scripts/{test_set}.sh {port} {model} {test_set}-{template_type}-{lang}")
        
if __name__ == '__main__':
    for model in model_list:
        p = subprocess.Popen(f"""python URLs/vllm_url.py \
            --model_name  {model_path[model]}\
            --gpuid  3\
            --port 6323""", 
            shell=True)
        pid = p.pid + 1
        time.sleep(120)
        auto_test(model)
        print(f"kill -9 {pid}")
        os.system(f"kill -9 {pid}")
        os.kill(pid, signal.SIGKILL)
        _, exit_status = os.waitpid(pid, 0)
        print(f"exit_status: {exit_status}")
        time.sleep(30)
        
    input_dir = "/home/wanghaoyu/UltraEval/result/humaneval"
    result = transform_humaneval(input_dir)
    for item in result:
        print(result[item])
    # if 'omgeval' in test_list:
    #     omg_eval(model_list, languages)